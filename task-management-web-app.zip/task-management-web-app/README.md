# Task Management Web App

A responsive task management web application built with HTML, CSS, JavaScript, Python Flask, and SQLite.

## Features

- User registration and login
- Password hashing
- Add tasks
- Edit tasks
- Delete tasks
- Mark tasks as Pending or Completed
- SQLite database integration
- User-specific task data
- Responsive UI
- Simple dashboard

## Tech Stack

- HTML5
- CSS3
- JavaScript
- Python
- Flask
- SQLite
- Werkzeug

## Project Structure

```text
task-management-web-app/
│
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
│
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── script.js
│
└── templates/
    ├── base.html
    ├── login.html
    ├── register.html
    ├── dashboard.html
    └── edit_task.html
```

## Run Locally

1. Install Python.
2. Open the project folder in a terminal.
3. Create a virtual environment:

```bash
python -m venv venv
```

4. Activate it:

Windows:
```bash
venv\Scripts\activate
```

macOS/Linux:
```bash
source venv/bin/activate
```

5. Install dependencies:

```bash
pip install -r requirements.txt
```

6. Start the application:

```bash
python app.py
```

7. Open:

```text
http://127.0.0.1:5000
```

The SQLite database `task_manager.db` is created automatically on first run.

## Resume Description

**Task Management Web App | HTML, CSS, JavaScript, Flask, SQLite**
- Developed a responsive task management web application with user registration and login.
- Implemented CRUD operations for creating, editing, deleting, and updating task status.
- Integrated SQLite database with Flask for persistent, user-specific task storage.
- Added password hashing and session-based authentication for secure user access.
